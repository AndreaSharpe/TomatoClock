#include "reset.h"
#include "ui_reset.h"

reset::reset(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::reset)
{
    ui->setupUi(this);
}

reset::~reset()
{
    delete ui;
}
