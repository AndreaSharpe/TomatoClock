#include "loginSystem.h"
#include "tcpserver.h"
// #include "body.h"
// #include "changepassworddialog.h"
// #include "tomatoclock.h"
// #include "personaldoc.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TcpServer server;  // 创建 TcpServer 实例
    // 启动服务器，这里假设我们使用默认的1234端口，但你可以根据需要更改它
    server.startServer(1234);
    LoginSystem w;
    w.show();
    // Body b;
    // b.show();
    // ChangePasswordDialog c;
    // c.show();
    // TomatoClock * t = new TomatoClock;
    // t->show();
    // personaldoc *p = new personaldoc;
    // p->show();
    return a.exec();
}
