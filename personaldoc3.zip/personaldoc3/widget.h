﻿#ifndef WIDGET_H
#define WIDGET_H

#include<vector>
#include<QDebug>

#include <QWidget>
#include <QPushButton>
#include <QStackedWidget>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QVBoxLayout>
#include <QFileDialog>
#include<QPainter>
#include<QCalendarWidget>
#include <QtCharts/QChartView>
#include<QDateEdit>
#include<QMessageBox>
#include<QBitmap>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QValueAxis>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtCharts/QBarSet>
#include <QtCharts/QBarSeries>
#include <QtCharts/QChart>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_btnPersonalInfo_clicked();

    void on_btnHistory_clicked();
    void on_btnUploadAvatar_clicked();
    void on_btnAchievements_clicked();

    void on_setPomodoros_clicked();

    void on_setDuration_clicked();

    void on_setPauses_clicked();

    void on_generateButton_clicked();

    void generateHistoryChart(const QDate &startdate,const QDate &enddate);

private:
    QWidget* personalInfoPage;
    QWidget* historyPage;
    QWidget* achievementsPage;

    Ui::Widget *ui;
    QLabel* lblAvatar;
    QComboBox* comboBoxGender;
    QtCharts::QChartView* currentChartView;
    bool showPomodoros_;
    bool showDuration_;
    bool showPauses_;
    QDateEdit *startDateEdit;
    QDateEdit *endDateEdit;

};

#endif // WIDGET_H
