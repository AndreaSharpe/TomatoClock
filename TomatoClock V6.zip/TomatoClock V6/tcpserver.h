#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QTcpServer>
#include <QObject>
#include "database.h"  // 确保包含 DataBase 类的头文件

class TcpServer : public QTcpServer {
    Q_OBJECT

public:
    explicit TcpServer(QObject *parent = nullptr);
    ~TcpServer();

    void startServer(quint16 port = 1234);  // 启动服务器，可以指定端口号

    void setCurrentUser(const QString &username) {
        this->currentUser = username;
    }

private slots:
    void handleNewConnection();  // 处理新连接的槽函数

private:
    void readClientData(QTcpSocket *socket);
    DataBase db;  // DataBase 实例，用于数据库操作
    QString currentUser;
};

#endif // TCPSERVER_H
