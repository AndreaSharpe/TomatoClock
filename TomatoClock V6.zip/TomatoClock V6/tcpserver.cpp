#include "tcpserver.h"
#include <QTcpSocket>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QDebug>

// TcpServer 类的构造函数实现
TcpServer::TcpServer(QObject *parent) : QTcpServer(parent), db() {
    // 可以在这里初始化数据库，但通常我们在用户登录后或其他特定时间点进行
    // 这里只是示例，我们假设数据库在构造时就已经准备好
}

// TcpServer 类的析构函数实现
TcpServer::~TcpServer() {
    // 在析构函数中，服务器通常会自动关闭所有连接并清理资源
    // 但这里不需要额外的清理，因为 QTcpServer 会处理这些
}

// startServer 成员函数的实现
void TcpServer::startServer(quint16 port) {
    if (!listen(QHostAddress::Any, port)) {
        qDebug() << "Server could not start!";
    } else {
        qDebug() << "Server started on port" << port;
        connect(this, &QTcpServer::newConnection, this, &TcpServer::handleNewConnection);
    }
}

// handleNewConnection 槽函数的实现
void TcpServer::handleNewConnection() {
    QTcpSocket *socket = nextPendingConnection();
    connect(socket, &QTcpSocket::readyRead, this, [this, socket]() {
        readClientData(socket);
    });
    connect(socket, &QTcpSocket::disconnected, socket, &QTcpSocket::deleteLater);
}

// readClientData 成员函数的实现（注意：这里我将其改为了成员函数而不是槽函数，因为它只在 handleNewConnection 中被调用）
void TcpServer::readClientData(QTcpSocket *socket) {
    QByteArray data = socket->readAll();
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        qDebug() << "Received data is not a valid JSON object";
        return;
    }

    QJsonObject obj = doc.object();
    QString taskName = obj.value("taskName").toString();
    int workTime = obj.value("workTime").toInt();
    int breakTime = obj.value("breakTime").toInt();

    // 假设 currentUser 已经被正确设置（在实际应用中，这可能需要不同的逻辑）
    if (!currentUser.isEmpty()) {
        db.insertTask(taskName, workTime, breakTime);
    } else {
        qDebug() << "No current user set, cannot insert task";
    }

    // 发送响应给客户端
    socket->write("Data received and processed");
}
