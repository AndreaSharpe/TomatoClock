﻿# pragma execution_character_set("utf-8")
#include "tomatoclock.h"
#include "ui_tomatoclock.h"
TomatoClock::TomatoClock(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TomatoClock)
    , m_personaldoc(new personaldoc(nullptr))
{
     m_personaldoc->hide();
    ui->setupUi(this);
    Opacity=0.9;
    state=0;
    tomato_num=0;
    timeset=25;
    breaktimeset=5;
    totaltime=0;
    player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromEncoded("qrc:/new/prefix2/t/Chillhop.mp3"));
    player->setVolume(30);
    progressbar=new QProgressBar(this);
    painter =new QPainter(this);
    ui->pic1->setStyleSheet("background:transparent");
    ui->pic2->setStyleSheet("background:transparent");
    ui->pic3->setStyleSheet("background:transparent");
    ui->pic4->setStyleSheet("background:transparent");
    ui->pic5->setStyleSheet("background:transparent");
    ui->progressBar->setStyleSheet("QProgressBar{height:22px; text-align:center; font-size:14px; color:white; border-radius:11px; background:#1D5573;}"
                                       "QProgressBar::chunk{border-radius:11px;background:qlineargradient(spread:pad,x1:0,y1:0,x2:1,y2:0,stop:0 #99ffff,stop:1 #9900ff);}");
    current_color = "background-color: #ADD8E6;";
    this->setStyleSheet(current_color);
    workname = new QList<QString>();
    worktime = new QList<int>();
    this->model=new QStandardItemModel;
    ui->table->setModel(model);
    model->setHorizontalHeaderItem(0,new QStandardItem("workname"));
    model->setHorizontalHeaderItem(1,new QStandardItem("worktime"));
    ui->table->setColumnWidth(0,200);
    ui->table->setColumnWidth(1,150);
    ui->table->setColumnWidth(2,220);
    this->setWindowFlag(Qt::FramelessWindowHint);
    this->setMinimumSize(45,45);
    this->setStyleSheet(current_color);
    this->setWindowOpacity(Opacity);  //透明度
    ::SetWindowPos(HWND(this->winId()),HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW);
    int wide=width();
    QToolButton *minButton=new QToolButton(this);  //设计按钮
    QToolButton *closeButton=new QToolButton(this);
    QPixmap minpix=style()->standardPixmap(QStyle::SP_TitleBarMinButton);
    QPixmap closepix=style()->standardPixmap(QStyle::SP_TitleBarCloseButton);
    minButton->setIcon(minpix);
    closeButton->setIcon(closepix);
    minButton->setGeometry(wide-65,5,20,20);
    closeButton->setGeometry(wide-25,5,20,20);
    minButton->setToolTip("最小化");
    closeButton->setToolTip("关闭");
    minButton->setStyleSheet("background-color:transparent;");
    closeButton->setStyleSheet("background-color:transparent");
    connect(closeButton,SIGNAL(clicked()),this,SLOT(windowclosed()));
    connect(minButton,SIGNAL(clicked()),this,SLOT(windowmin()));
    initSysTrayIcon();
    timer=new QTimer;//计时器初始化
    ui->Timer->setDigitCount(5);
    initTime();
    timer->setInterval(1000);
    connect(timer,SIGNAL(timeout()),this,SLOT(updateTime()));

}

TomatoClock::~TomatoClock()
{
    delete ui;
}

void TomatoClock::mousePressEvent(QMouseEvent *e)
{
    if(e->button()==Qt::LeftButton)
       { clickPos=e->pos();}
    this->setWindowOpacity(Opacity);
    if(state==1)  //暂停
    {
        state=0;
        player->pause();
        this->setStyleSheet("background:#5698c3");
        Opacity=0.8;
        timer->stop();
        this->setWindowOpacity(Opacity);
        m_pauseaction->setText("暂停");
    }
    else  //继续
    {
        state=1;
        timer->start();
        player->play();
        this->setStyleSheet(current_color);
        Opacity=0.9;
        m_pauseaction->setText("继续");
    }
    this->setWindowOpacity(Opacity);
}

void TomatoClock::initTime()
{
    time.setHMS(0,0,0);
    ui->Timer->display(time.toString("mm:ss"));
}

void TomatoClock::mouseMoveEvent(QMouseEvent *e)
{
    if(e->buttons()&Qt::LeftButton)
        move(e->pos()+pos()-clickPos);
}

void TomatoClock::updateTime()  //刷新lcd时间
{
    time=time.addSecs(1);
    ui->Timer->display(time.toString("mm:ss"));
    if(time.minute()==breaktimeset && tomato_num==1)  //休息时间结束
    {
        tomato_num=0;
        initTime();
        current_color="background:#cd9b9b";   //红色
        this->setStyleSheet(current_color);
    }else if(time.minute()==timeset)   //工作时间结束，进入休息
    {
        tomato_num++;
        updatelist();
        initTime();
        current_color="background:#9bcd9b";
        this->setStyleSheet(current_color);
    }
}

void TomatoClock::on_overbutton_clicked()  //重置
{
    time.setHMS(0,40,0);
    updatelist();
    initTime();
    timer->stop();
    player->pause();
    state=0;
    this->setStyleSheet("background:#5698c3");
    Opacity=0.8;
    this->setWindowOpacity(Opacity);
}

void TomatoClock::on_timeset_text_returnPressed()  //设置单次时间
{
    QString a=ui->timeset_text->text();
    timeset=a.toInt();
}

void TomatoClock::on_breaktime_text_returnPressed()
{
    QString a=ui->breaktime_text->text();
    breaktimeset=a.toInt();
}

void TomatoClock::windowclosed()
{
    this->close();
}

void TomatoClock::windowmin()
{
    this->showMinimized();
}

void TomatoClock::updatelist()
{
    QString tmp=ui->workname_text->text();
   int index=workname->indexOf(tmp);
   if(index>=0)
   {
       totaltime+=time.minute();
       worktime->replace(index,time.minute()+worktime->at(index));
       model->setItem(index,1,new QStandardItem(QString::number(worktime->at(index))));
       ui->totaltime_label->setText(QString::number(totaltime)+QString("分钟"));
       if(totaltime>=150)
       {
           ui->progressBar->setValue(150);
       }
       else{
       ui->progressBar->setValue(totaltime);
       }
       checktime();
   }
   else
   {
       workname->append(tmp);
       worktime->append(time.minute());
       int n=workname->size();
       ui->table->setRowHeight(n-1,50);
       model->setItem(n-1,0,new QStandardItem(workname->at(n-1)));
       model->setItem(n-1,1,new QStandardItem(QString::number(worktime->at(n-1))));
       model->setHeaderData(n-1,Qt::Vertical,"行"+QString::number(n));
       totaltime+=worktime->at(n-1);
       ui->totaltime_label->setText(QString::number(totaltime)+QString("分钟"));

       if(ui->progressBar->value()>=150)
       {
           ui->progressBar->setValue(149);
       }
       else{
       ui->progressBar->setValue(totaltime);
       }
       checktime();
   }
}

void TomatoClock::checktime()
{
    if(totaltime>=150)
    {
        QPixmap*pic5=new QPixmap(":/new/prefix1/t/pic5.png");
        pic5->scaled(ui->pic5->size(),Qt::KeepAspectRatio);
        ui->pic5->setScaledContents(true);
        ui->pic5->setPixmap(*pic5);
        all_success=new QMediaPlayer;
        connect(success, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
        all_success->setMedia(QUrl::fromEncoded("qrc:/new/prefix3/t/all_success.mp3"));
        all_success->setVolume(30);
        all_success->play();
    }
    if(totaltime>=120)
    {
        QPixmap*pic4=new QPixmap(":/new/prefix1/t/pic4.png");
        pic4->scaled(ui->pic4->size(),Qt::KeepAspectRatio);
        ui->pic4->setScaledContents(true);
        ui->pic4->setPixmap(*pic4);
        success->play();
    }
    if(totaltime>=90)
    {
        QPixmap*pic3=new QPixmap(":/new/prefix1/t/pic3.png");
        pic3->scaled(ui->pic3->size(),Qt::KeepAspectRatio);
        ui->pic3->setScaledContents(true);
        ui->pic3->setPixmap(*pic3);
        success->play();
    }
    if(totaltime>=60)
    {
        QPixmap*pic2=new QPixmap(":/new/prefix1/t/pic2.png");
        pic2->scaled(ui->pic2->size(),Qt::KeepAspectRatio);
        ui->pic2->setScaledContents(true);
        ui->pic2->setPixmap(*pic2);
        success->play();
    }
    if(totaltime>=30)
    {
        QPixmap*pic1=new QPixmap(":/new/prefix1/t/pic1.png");
        pic1->scaled(ui->pic1->size(),Qt::KeepAspectRatio);
        ui->pic1->setScaledContents(true);
        ui->pic1->setPixmap(*pic1);
        mediasetup();
        success->play();
    }
}

 void TomatoClock::mediasetup()
 {
     success=new QMediaPlayer;
     connect(success, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
     success->setMedia(QUrl::fromEncoded("qrc:/new/prefix3/t/mission_success.mp3"));
     success->setVolume(30);
 }

 //创建系统托盘
 void TomatoClock::initSysTrayIcon()
 {
     //隐藏程序主窗口
     this->hide();

     //新建QSystemTrayIcon对象
     m_sysTrayIcon = new QSystemTrayIcon(this);

     //设置托盘图标
     QIcon icon = QIcon(":/new/prefix4/t/logo.png");    //资源文件添加的图标
     m_sysTrayIcon->setIcon(icon);

     //当鼠标移动到托盘上的图标时，会显示此处设置的内容
     m_sysTrayIcon->setToolTip("单击关闭窗口");
    connect(m_sysTrayIcon,SIGNAL(activated(QSystemTrayIcon::ActivationReason)),this,SLOT(on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason)));


     //建立托盘操作的菜单
     createActions();
     createMenu();
     //在系统托盘显示此对象
     m_sysTrayIcon->show();
 }

 //创建动作
 void TomatoClock::createActions()
 {
     m_showMainAction = new QAction("个人中心", this);
     connect(m_showMainAction,SIGNAL(triggered()),this,SLOT(on_showMainAction()));
     m_exitAppAction = new QAction("退出", this);
     connect(m_exitAppAction,SIGNAL(triggered()),this,SLOT(on_exitAppAction()));
     m_pauseaction = new QAction("早上好", this);
     connect(m_pauseaction,SIGNAL(triggered()),this,SLOT(on_pauseaction()));
 }//更改内容

 //创建托盘菜单
 void TomatoClock::createMenu()
 {
     m_menu = new QMenu(this);
     //新增菜单项---显示主界面
     m_menu->addAction(m_showMainAction);
     //增加分隔符
     m_menu->addSeparator();
     //新增菜单项---退出程序
     m_menu->addAction(m_exitAppAction);
     //把QMenu赋给QSystemTrayIcon对象
     m_sysTrayIcon->setContextMenu(m_menu);
     m_menu->addSeparator();
     m_menu->addAction(m_pauseaction);
 }

 //当在系统托盘点击菜单内的显示个人中心界面操作
 void TomatoClock::on_showMainAction()
 {
     m_personaldoc->show(); // 显示个人中心页面

 }

 //当在系统托盘点击菜单内的退出程序操作
 void TomatoClock::on_exitAppAction()
 {
     qApp->exit();
 }

 //关闭事件
 void TomatoClock::closeEvent(QCloseEvent *event)
 {
     //忽略窗口关闭事件
     QApplication::setQuitOnLastWindowClosed( true );
     this->hide();
     event->ignore();
 }

 void TomatoClock::changeEvent(QEvent *event)
 {
    if((event->type()==QEvent::WindowStateChange)&&isMinimized())
    {
        hide();
        m_sysTrayIcon->showMessage("SystemTrayIcon",QObject::trUtf8("程序最小化到托盘"),QSystemTrayIcon::Information,10000);
        event->ignore();
    }
 }

 void TomatoClock::on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason reason)
 {
     switch(reason){
     case QSystemTrayIcon::Trigger:
         //单击托盘图标
         this->hide();
         break;
     case QSystemTrayIcon::DoubleClick:
         //双击托盘图标
         //双击后显示主程序窗口
         this->showNormal();
         break;
     default:
         break;
     }
 }

void  TomatoClock::on_pauseaction()
{
    if(state==1)
    {
        m_pauseaction->setText("继续");
        state=0;
        player->pause();
        this->setStyleSheet("background:#7ac5cd");
        Opacity=0.4;
        timer->stop();
        this->setWindowOpacity(Opacity);
        return;
    }
    else if(state==0)
    {
        m_pauseaction->setText("暂停");
        state=1;
        timer->start();
        player->play();
        this->setStyleSheet(current_color);
        Opacity=0.8;
    }
}

void TomatoClock::on_soundalue_slider_valueChanged(int value)
{
    player->setVolume(value);
}
