#pragma execution_character_set("utf-8")//��֤�����ַ������������
#include "personaldoc2.h"  

Widget::Widget(QWidget* parent)
    : QWidget(parent)
{
    setupUI();
}

Widget::~Widget()
{
}

void Widget::setupLeftPanel() {
    QVBoxLayout* leftLayout = new QVBoxLayout;
    btnPersonalInfo = new QPushButton("������Ϣ");
    btnPersonalInfo->setFixedSize(100, 30);
    leftLayout->addWidget(btnPersonalInfo);

    btnHistory = new QPushButton("��ʷ��¼");
    btnHistory->setFixedSize(100, 30);
    leftLayout->addWidget(btnHistory);

    btnAchievements = new QPushButton("�ɾ�");
    btnAchievements->setFixedSize(100, 30);
    leftLayout->addWidget(btnAchievements);

    leftPanel = new QWidget;
    leftPanel->setLayout(leftLayout);
}

void Widget::setupUI()
{
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    setupLeftPanel();

    stackedWidget = new QStackedWidget(this);
    personalInfoPage = new QWidget();
    historyPage = new QWidget();
    achievementsPage = new QWidget();

    setupPersonalInfoPage();
    setupHistoryPage();
    setupAchievementsPage();

    stackedWidget->addWidget(personalInfoPage);
    stackedWidget->addWidget(historyPage);
    stackedWidget->addWidget(achievementsPage);

    mainLayout->addWidget(leftPanel);
    mainLayout->addWidget(stackedWidget);

    connect(btnPersonalInfo, &QPushButton::clicked, this, &Widget::onButtonClicked);
    connect(btnHistory, &QPushButton::clicked, this, &Widget::onButtonClicked);
    connect(btnAchievements, &QPushButton::clicked, this, &Widget::onButtonClicked);


    setLayout(mainLayout);  // ȷ�����������������  
}

void Widget::onButtonClicked()
{
    if (sender() == btnPersonalInfo)
        stackedWidget->setCurrentIndex(0);
    else if (sender() == btnHistory)
        stackedWidget->setCurrentIndex(1);
    else if (sender() == btnAchievements)
        stackedWidget->setCurrentIndex(2);
}

void Widget::setupPersonalInfoPage()
{
    QVBoxLayout* layout = new QVBoxLayout(personalInfoPage);
    lblAvatar = new QLabel(personalInfoPage);
    lblAvatar->setFixedSize(100, 100);
    lblAvatar->setPixmap(QPixmap(":/default_avatar.png"));
    layout->addWidget(lblAvatar);

    btnUploadAvatar = new QPushButton("�ϴ�ͷ��", personalInfoPage);
    layout->addWidget(btnUploadAvatar);
    connect(btnUploadAvatar, &QPushButton::clicked, this, &Widget::onUploadAvatarClicked);

    lineEditNickname = new QLineEdit(personalInfoPage);
    layout->addWidget(new QLabel("�ǳ�:", personalInfoPage));
    layout->addWidget(lineEditNickname);

    comboBoxGender = new QComboBox(personalInfoPage);
    comboBoxGender->addItem("��");
    comboBoxGender->addItem("Ů");
    comboBoxGender->addItem("����");
    layout->addWidget(new QLabel("�Ա�:", personalInfoPage));
    layout->addWidget(comboBoxGender);

    lblEmail = new QLabel("�Ѱ�����: example@example.com", personalInfoPage);
    layout->addWidget(lblEmail);
}

void Widget::onUploadAvatarClicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "ѡ��ͷ��", "", "ͼƬ�ļ� (*.png *.jpg *.jpeg *.bmp)");
    if (!fileName.isEmpty()) {
        QPixmap originalPixmap(fileName);
        int avatarSize = 100;
        QPixmap roundedPixmap = originalPixmap.scaled(avatarSize, avatarSize, Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation);
        QPixmap maskPixmap(avatarSize, avatarSize);
        maskPixmap.fill(Qt::transparent);
        QPainter painter(&maskPixmap);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.setBrush(QBrush(Qt::black));
        painter.drawEllipse(0, 0, avatarSize, avatarSize);
        roundedPixmap.setMask(maskPixmap.mask());
        lblAvatar->setPixmap(roundedPixmap);
    }
}

void Widget::setupHistoryPage()
{
    QVBoxLayout* layout = new QVBoxLayout(historyPage);
    QLabel* label = new QLabel("��ʷ��¼ҳ", historyPage);
    layout->addWidget(label);

    // ��������ѡ����  
    QCalendarWidget* calendar = new QCalendarWidget(historyPage);
    layout->addWidget(calendar);

    // ����������״ͼ�İ�ť��ע�⣺�����ť����ֻ���ڴ���ͼ�����ɣ���ֱ�ӿ�����ʾ���ݣ�  
    QPushButton* generateButton = new QPushButton("������״ͼ", historyPage);
    connect(generateButton, &QPushButton::clicked, this, &Widget::generateHistoryChart);
    layout->addWidget(generateButton);

    // ���ӿ�����ʾ���ݵİ�ť  
    QPushButton* pomodorosButton = new QPushButton("��ʾ��ɵķ����Ӹ���", historyPage);
    connect(pomodorosButton, &QPushButton::clicked, this, &Widget::displayPomodoros);
    layout->addWidget(pomodorosButton);

    QPushButton* durationButton = new QPushButton("��ʾ��ʱ��", historyPage);
    connect(durationButton, &QPushButton::clicked, this, &Widget::displayDuration);
    layout->addWidget(durationButton);

    QPushButton* pausesButton = new QPushButton("��ʾ��ͣ����", historyPage);
    connect(pausesButton, &QPushButton::clicked, this, &Widget::displayPauses);
    layout->addWidget(pausesButton);

    connect(pomodorosButton, &QPushButton::clicked, this, &Widget::displayPomodoros);
    connect(durationButton, &QPushButton::clicked, this, &Widget::displayDuration);
    connect(pausesButton, &QPushButton::clicked, this, &Widget::displayPauses);
}

void Widget::displayPomodoros()
{
    showPomodoros_ = true;
    showDuration_ = false;
    showPauses_ = false;
    generateHistoryChart();
}

void Widget::displayDuration()
{
    showPomodoros_ = false;
    showDuration_ = true;
    showPauses_ = false;
    generateHistoryChart();
}

void Widget::displayPauses()
{
    showPomodoros_ = false;
    showDuration_ = false;
    showPauses_ = true;
    generateHistoryChart();
}

// ����һ���ۺ������������ɲ���ʾ��״ͼ  
void Widget::generateHistoryChart()
{
    // �� SQLite ���ݿ�  
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("path_to_your_database.db");
    QDataStream dataStream;
    if (!db.open()) {
        return;
    }

    // ִ�� SQL ��ѯ�Ի�ȡ��ʷ��¼����  
    QSqlQuery query;
    query.exec("SELECT date, completed_pomodoros, total_duration, pauses FROM history WHERE date BETWEEN 'start_date' AND 'end_date'");

    // ��ʼ��ͼ����������ݽṹ  
    QVector<QString> categories;  
    QVector<int> pomodorosData;  
    QVector<int> durationData;  
    QVector<int> pausesData;  

    // ������ѯ������ռ�����  
    while (query.next()) {
        QString date = query.value(0).toString();
        int pomodoros = query.value(1).toInt();
        int duration = query.value(2).toInt();
        int pauseCount = query.value(3).toInt();

        categories.append(date);
        if (showPomodoros_) pomodorosData.append(pomodoros);
        if (showDuration_) durationData.append(duration);
        if (showPauses_) pausesData.append(pauseCount);
    }

    // ����Ѿ���һ��ͼ����ͼ�����Ƴ���    
    if (currentChartView!= nullptr) {
        historyPage->layout()->removeWidget(currentChartView);
        delete currentChartView;
        currentChartView= nullptr;
    }

    // ������״ͼ  
    QtCharts::QChart* chart = new QtCharts::QChart();
    QtCharts::QBarSeries* series = new QtCharts::QBarSeries();

    if (showPomodoros_) {
        QtCharts::QBarSet* setPomodoros = new QtCharts::QBarSet("��ɵķ����Ӹ���");
        for (int pomodoro : pomodorosData) { 
            *setPomodoros << pomodoro; 
        }
        series->append(setPomodoros);
    }
    if (showDuration_) {
        QtCharts::QBarSet* setDuration = new QtCharts::QBarSet("��ʱ��");
        for (int duration : durationData) { 
            *setDuration << duration;   
        }
        series->append(setDuration);
    }
    if (showPauses_) {
        QtCharts::QBarSet* setPauses = new QtCharts::QBarSet("��ͣ����");
        for (int pause : pausesData) {   
            *setPauses << pause;   
        }
        series->append(setPauses);
    }


    chart->addSeries(series);
    chart->setTitle("��ʷ��¼��״ͼ");
    chart->setAnimationOptions(QtCharts::QChart::SeriesAnimations);

    // ����������      
    QStringList categoriesList;
    for (const QString& category : categories) {
        categoriesList.append(category);
    }

    QtCharts::QBarCategoryAxis* axisX = new QtCharts::QBarCategoryAxis();
    axisX->append(categoriesList);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    QtCharts::QValueAxis* axisY = new QtCharts::QValueAxis();
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    // ��ʾͼ��    
    QtCharts::QChartView* chartView = new QtCharts::QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    historyPage->layout()->addWidget(chartView);

    // ���³�Ա������ָ���µ�ͼ����ͼ    
    currentChartView = chartView;
}



void Widget::setupAchievementsPage()
{
    QVBoxLayout* layout = new QVBoxLayout(achievementsPage);
    QLabel* label = new QLabel("�ɾ�ҳ", achievementsPage);
    layout->addWidget(label);

    // ������һ����������ȡ�û��ĳɾͣ����������������ǵ�ҳ����  
    // ���磺addAchievementsToPage(layout);  
}
